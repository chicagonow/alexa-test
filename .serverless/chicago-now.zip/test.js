const index = require('./index');

index.dumbAdditionTest();