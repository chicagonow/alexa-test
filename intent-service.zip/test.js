const index = require('./index');

index.requestTest();